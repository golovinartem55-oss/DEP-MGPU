{{ config(materialized='view') }}

SELECT
    customer_id,
    UPPER(TRIM(customer_name)) AS customer_name,
    UPPER(TRIM(region)) AS region,
    sales_amount,
    order_date,
    contract_start_date,
    CURRENT_DATE - contract_start_date::DATE AS contract_duration_days
FROM raw_data.sales_raw
WHERE
    customer_id IS NOT NULL
    AND sales_amount > 0
    AND contract_start_date IS NOT NULL;
