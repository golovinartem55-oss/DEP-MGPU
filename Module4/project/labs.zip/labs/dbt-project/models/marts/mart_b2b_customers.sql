{{ config(materialized='table') }}

WITH customer_agg AS (
    SELECT
        customer_id,
        customer_name,
        region,
        COUNT(*) AS total_orders,
        SUM(sales_amount) AS total_revenue,
        AVG(sales_amount) AS avg_contract_size,
        MAX(contract_duration_days) AS max_contract_duration
    FROM {{ ref('int_sales_cleaned') }}
    GROUP BY customer_id, customer_name, region
),
total_sales AS (
    SELECT SUM(total_revenue) AS grand_total
    FROM customer_agg
)
SELECT
    c.customer_id,
    c.customer_name,
    c.region,
    c.total_orders,
    c.total_revenue,
    ROUND(c.avg_contract_size, 2) AS avg_contract_size,
    c.max_contract_duration,
    ROUND((c.total_revenue / t.grand_total) * 100, 2) AS market_share_percent
FROM customer_agg c
CROSS JOIN total_sales t
ORDER BY c.total_revenue DESC;9
