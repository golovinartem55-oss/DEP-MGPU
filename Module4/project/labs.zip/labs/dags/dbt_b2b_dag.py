from datetime import datetime
from airflow import DAG
from airflow.operators.bash import BashOperator

DBT_PROJECT_DIR = "/opt/airflow/dbt-project"

default_args = {
    "owner": "airflow",
    "start_date": datetime(2025, 1, 1),
    "retries": 1,
}

dag = DAG(
    "dbt_b2b_analytics",
    default_args=default_args,
    description="ETL for B2B customer analysis using dbt",
    schedule_interval=None,
    catchup=False,
)

dbt_run = BashOperator(
    task_id="dbt_run",
    bash_command=f"cd {DBT_PROJECT_DIR} && dbt run",
    dag=dag,
)

dbt_test = BashOperator(
    task_id="dbt_test",
    bash_command=f"cd {DBT_PROJECT_DIR} && dbt test",
    dag=dag,
)

dbt_run >> dbt_test
