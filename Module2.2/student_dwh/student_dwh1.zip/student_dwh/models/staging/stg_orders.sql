
 
SELECT
    "Row ID"::INTEGER AS row_id,
    "Order ID"::VARCHAR AS order_id,
    "Order Date"::DATE AS order_date,
    "Ship Date"::DATE AS ship_date,
    "Ship Mode"::VARCHAR AS ship_mode,
    "Customer ID"::VARCHAR AS customer_id,
    "Customer Name"::VARCHAR AS customer_name,
    "Segment"::VARCHAR AS segment,
    "Country"::VARCHAR AS country,
    "City"::VARCHAR AS city,
    "State"::VARCHAR AS state,
    "Postal Code"::INTEGER AS postal_code,
    "Region"::VARCHAR AS region,
    "Product ID"::VARCHAR AS product_id,
    "Category"::VARCHAR AS category,
    "Sub-Category"::VARCHAR AS subcategory,
    "Product Name"::VARCHAR AS product_name,
    "Sales"::NUMERIC AS sales,
    "Quantity"::INTEGER AS quantity,
    "Discount"::NUMERIC AS discount,
    "Profit"::NUMERIC AS profit
FROM {{ source('stg', 'orders') }}
