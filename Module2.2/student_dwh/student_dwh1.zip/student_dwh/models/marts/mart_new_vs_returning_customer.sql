-- models/marts/mart_new_vs_returning_customers.sql
-- Витрина: выручка от новых и вернувшихся клиентов по месяцам
 
WITH customer_first_order AS (
    SELECT
        customer_id,
        MIN(order_date) AS first_order_date
    FROM {{ ref('int_sales_orders') }}
    GROUP BY customer_id
),
 
orders_with_customer_type AS (
    SELECT
        s.order_id,
        s.customer_id,
        s.sales,
        DATE_TRUNC('month', s.order_date)::DATE AS order_month,
        CASE
            WHEN cfo.first_order_date >= DATE_TRUNC('month', s.order_date)
                 AND cfo.first_order_date < DATE_TRUNC('month', s.order_date) + INTERVAL '1 month'
            THEN 'new'
            ELSE 'returning'
        END AS customer_type
    FROM {{ ref('int_sales_orders') }} s
    LEFT JOIN customer_first_order cfo
        ON s.customer_id = cfo.customer_id
)
 
SELECT
    order_month,
    customer_type,
    SUM(sales) AS revenue
FROM orders_with_customer_type
GROUP BY order_month, customer_type
ORDER BY order_month, customer_type;
