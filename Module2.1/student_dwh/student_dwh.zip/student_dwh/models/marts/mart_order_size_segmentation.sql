SELECT
    order_size_segment,
    COUNT(*) AS order_count
FROM (
    SELECT
        order_id,
        sales,
        CASE
            WHEN sales > 1000 THEN 'Крупные'
            WHEN sales >= 100 AND sales <= 1000 THEN 'Средние'
            WHEN sales < 100 THEN 'Мелкие'
            ELSE 'Неопределено'
        END AS order_size_segment
    FROM {{ ref('sales_fact') }}
    WHERE sales IS NOT NULL
) AS segmented_orders
GROUP BY order_size_segment
ORDER BY
    CASE order_size_segment
        WHEN 'Крупные' THEN 1
        WHEN 'Средние' THEN 2
        WHEN 'Мелкие' THEN 3
        ELSE 4
    END
