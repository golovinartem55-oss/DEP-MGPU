SELECT
    o.order_id,
    c.customer_id,
    g.geo_id,
    p.product_id,
    s.shipping_id,
    o.sales,
    o.profit,
    o.quantity,
    o.order_date,
    o.ship_date
FROM {{ ref('stg_orders') }} AS o
LEFT JOIN {{ ref('customer_dim') }} AS c
    ON o.customer_id = c.customer_id
    AND o.customer_name = c.customer_name
LEFT JOIN {{ ref('geo_dim') }} AS g
    ON o.state = g.state
    AND o.city = g.city
    AND o.postal_code = g.postal_code
    AND o.region = g.region
LEFT JOIN {{ ref('product_dim') }} AS p
    ON o.product_id = p.product_id
    AND o.product_name = p.product_name
    AND o.category = p.category
    AND o.subcategory = p.subcategory
LEFT JOIN {{ ref('shipping_dim') }} AS s
    ON o.ship_mode = s.shipping_mode
